# Dio Dino Game 
Dino game for Digital Innovation One Lesson, using only JS, HTML and CSS

![screenshot](example.png?raw=true "screenshot")

# License
This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details
